<?php
require_once '../classes/Task.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];

    $task = new Task();
    if ($task->updateTask($id, $title, $due_date, $status)) {
        header('Location: ../index.php');
    } else {
        echo "Error updating task.";
    }
}
?>

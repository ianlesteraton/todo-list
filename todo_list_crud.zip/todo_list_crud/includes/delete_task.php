<?php
require_once '../classes/Task.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    $task = new Task();
    if ($task->deleteTask($id)) {
        header('Location: ../index.php');
    } else {
        echo "Error deleting task.";
    }
}
?>

<?php
require_once '../classes/Task.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $due_date = $_POST['due_date'];

    $task = new Task();
    if ($task->createTask($title, $due_date, $priority, $category)) {
        header('Location: ../index.php');
    } else {
        echo "Error adding task.";
    }
}
?>

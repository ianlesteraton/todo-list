<?php
require_once '../classes/Task.php';

$task = new Task();
$tasks = $task->getTasks('Pending');
$near_deadline = [];

foreach ($tasks as $t) {
    $due_time = strtotime($t['due_date']); 
    $current_time = time(); 

    if ($due_time - $current_time <= 3600) { 
        $near_deadline[] = $t; 
    }
}

echo json_encode($near_deadline);
?>

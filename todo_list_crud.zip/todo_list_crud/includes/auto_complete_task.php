<?php
require_once '../classes/Task.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $taskId = $data['id'];

    if ($taskId) {
        $task = new Task();
        
        // Check if the task is already completed
        $taskData = $task->getTaskById($taskId);
        if ($taskData['status'] === 'Completed') {
            echo json_encode(['success' => false, 'error' => 'Task is already completed.']);
            exit;
        }

        // Update task status to "Completed"
        $updated = $task->updateTaskStatus($taskId, 'Completed');

        if ($updated) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update task status.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid task ID.']);
    }
}
?>

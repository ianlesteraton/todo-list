<?php
require_once 'database.php';

class Task {
    private $conn;
    private $table_name = "tasks";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function createTask($title, $due_date) {
        $query = "INSERT INTO " . $this->table_name . " (title, due_date) VALUES (:title, :due_date)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':due_date', $due_date);
        return $stmt->execute();
    }

    public function getTasks($status = null) {
        $query = "SELECT * FROM " . $this->table_name;
        if ($status) {
            $query .= " WHERE status = :status";
        }
        $stmt = $this->conn->prepare($query);
        if ($status) {
            $stmt->bindParam(':status', $status);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateTask($id, $title, $due_date, $status) {
        $query = "UPDATE " . $this->table_name . " SET title = :title, due_date = :due_date, status = :status WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':due_date', $due_date);
        $stmt->bindParam(':status', $status);
        return $stmt->execute();
    }

    public function deleteTask($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
    
    public function updateTaskStatus($id, $status) {
        $stmt = $this->conn->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }
    
    public function getTaskById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM tasks WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
}
?>

<?php
require_once 'classes/Task.php';

$task = new Task();
$pendingTasks = $task->getTasks('Pending');
$completedTasks = $task->getTasks('Completed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>To-Do List</h1>

        <?php
        $totalTasks = count($task->getTasks());
        $pendingTasksCount = count($pendingTasks);
        $completedTasksCount = count($completedTasks);
        ?>

        <div class="summary">
            <h2>Task Summary</h2>
            <p>Total Tasks: <?= $totalTasks ?></p>
            <p>Pending Tasks: <?= $pendingTasksCount ?></p>
            <p>Completed Tasks: <?= $completedTasksCount ?></p>
        </div>

        <div>
            <form action="includes/add_task.php" method="POST">
                <input type="text" name="title" placeholder="Task Title" required>
                <input type="datetime-local" name="due_date" required>
                <button type="submit">Add Task</button>
            </form>
        </div>

        <h2>Pending Tasks</h2>
        <ul>
            <?php foreach ($pendingTasks as $task): ?>
                <li 
                    data-id="<?= $task['id'] ?>"
                    data-due-date="<?= $task['due_date'] ?>"
                    data-title="<?= $task['title'] ?>">
                    <strong><?= $task['title'] ?></strong>
                    <p>Due Date: <?= $task['due_date'] ?></p>
                    <p>Time Remaining: <span class="time-remaining" data-due-date="<?= $task['due_date'] ?>"></span></p>
                    <div class="task-buttons">
                        <button class="update" onclick="openUpdateModal(<?= $task['id'] ?>, '<?= $task['title'] ?>', '<?= $task['due_date'] ?>', '<?= $task['status'] ?>')">Update</button>
                        <form action="includes/delete_task.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?= $task['id'] ?>">
                            <button class="delete" onclick="return confirm('Are you sure?');">Delete</button>
                        </form>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>

        <h2>Completed / Overdue Tasks</h2>
        <ul>
            <?php foreach ($completedTasks as $task): ?>
                <li 
                    data-id="<?= $task['id'] ?>"
                    data-due-date="<?= $task['due_date'] ?>"
                    data-title="<?= $task['title'] ?>">
                    <strong><?= $task['title'] ?></strong>
                    <p>Due Date: <?= $task['due_date'] ?></p>
                    <p>Time Remaining: <span class="time-remaining" data-due-date="<?= $task['due_date'] ?>"></span></p>
                    <div class="task-buttons">
                        <button class="update" onclick="openUpdateModal(<?= $task['id'] ?>, '<?= $task['title'] ?>', '<?= $task['due_date'] ?>', '<?= $task['status'] ?>')">Update</button>
                        <form action="includes/delete_task.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?= $task['id'] ?>">
                            <button class="delete" onclick="return confirm('Are you sure?');">Delete</button>
                        </form>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>

        <!-- Update Task Form Modal -->
        <div id="updateTaskModal" style="display:none;">
            <form action="includes/update_task.php" method="POST">
                <input type="hidden" name="id" id="updateTaskId">
                <input type="text" name="title" id="updateTaskTitle" placeholder="Task Title" required>
                <input type="datetime-local" name="due_date" id="updateTaskDueDate" required>
                <select name="status" id="updateTaskStatus">
                    <option value="Pending">Pending</option>
                    <option value="Completed">Completed</option>
                </select>
                <button type="submit">Update Task</button>
                <button type="button" onclick="closeUpdateModal()">Cancel</button>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
    <script src="js/notifications.js"></script>
</body>
</html>

function checkNotifications() {
    const taskElements = document.querySelectorAll('[data-due-date]');
    const currentTime = new Date();

    taskElements.forEach(task => {
        const dueDate = new Date(task.dataset.dueDate);
        const timeDifference = (dueDate - currentTime) / 1000; // Time difference in seconds

        if (timeDifference <= 3600) { // Within one hour
            task.classList.add('notification');
        } else {
            task.classList.remove('notification');
        }
    });
}

// Check notifications every minute
setInterval(checkNotifications, 60000);

// Run the check immediately on page load
checkNotifications();

// Open and Close Update Modal
function openUpdateModal(id, title, dueDate, status) {
    document.getElementById('updateTaskId').value = id;
    document.getElementById('updateTaskTitle').value = title;
    document.getElementById('updateTaskDueDate').value = dueDate;
    document.getElementById('updateTaskStatus').value = status;

    document.getElementById('updateTaskModal').style.display = 'block';
    document.getElementById('modalOverlay').style.display = 'block';
}

function closeUpdateModal() {
    document.getElementById('updateTaskModal').style.display = 'none';
    document.getElementById('modalOverlay').style.display = 'none';
}



function checkNotifications() {
    const taskElements = document.querySelectorAll('[data-due-date]');
    const currentTime = new Date();

    taskElements.forEach(task => {
        const dueDate = new Date(task.dataset.dueDate);
        const timeDifference = (dueDate - currentTime) / 1000; // Time difference in seconds

        if (timeDifference <= 3600) { // Within one hour
            task.classList.add('notification');
        } else {
            task.classList.remove('notification');
        }
    });
}

setInterval(checkNotifications, 60000); // Check every minute

document.addEventListener('DOMContentLoaded', () => {
    const timeRemainingElements = document.querySelectorAll('.time-remaining');

    function updateTimers() {
        const now = new Date();

        timeRemainingElements.forEach(el => {
            const dueDate = new Date(el.dataset.dueDate);
            const taskId = el.closest('li').getAttribute('data-id');
            const taskTitle = el.closest('li').getAttribute('data-title');
            const timeDiff = dueDate - now;

            if (timeDiff > 0) {
                const hours = Math.floor(timeDiff / (1000 * 60 * 60));
                const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
                el.textContent = `${hours}h ${minutes}m ${seconds}s`;
            } else {
                el.textContent = "Overdue!";
                // Auto-move the task to completed only once
                autoMoveToCompleted(taskId, taskTitle, el.closest('li'));
            }
        });
    }

    function autoMoveToCompleted(taskId, taskTitle, taskElement) {
        fetch('includes/auto_complete_task.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: taskId })
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(`Task "${taskTitle}" has been automatically marked as completed.`);
                    taskElement.remove(); // Remove from Pending Tasks UI
                    location.reload(); // Reload page to update Completed Tasks
                } else {
                    console.error(data.error || 'Failed to auto-complete task.');
                }
            });
    }

    // Start the live timer
    setInterval(updateTimers, 1000);
});



document.addEventListener('DOMContentLoaded', () => {
    const toggleDarkModeButton = document.createElement('button');
    toggleDarkModeButton.className = 'toggle-dark-mode';
    toggleDarkModeButton.innerText = 'Dark Mode';

    document.body.appendChild(toggleDarkModeButton);

    toggleDarkModeButton.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
    });
});



self.onmessage = function (e) {
    const tasks = e.data; // Receive task list from the main script
    const currentTime = new Date().getTime();

    tasks.forEach(task => {
        const dueDate = new Date(task.due_date).getTime();
        const timeLeft = dueDate - currentTime;

        if (timeLeft <= 3600000 && timeLeft > 0) { // 1 hour or less
            self.postMessage({
                message: `Task "${task.title}" is within 1 hour from its deadline!`,
                timeLeft: Math.floor(timeLeft / 60000) + " minutes left",
            });
        }
    });

    // Re-check every 5 minutes
    setTimeout(() => {
        self.postMessage("recheck");
    }, 5 * 60 * 1000);
};
